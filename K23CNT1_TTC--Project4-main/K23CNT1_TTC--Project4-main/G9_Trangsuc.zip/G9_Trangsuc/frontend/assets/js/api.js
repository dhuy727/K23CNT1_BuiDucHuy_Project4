window.API_BASE_URL = window.API_BASE_URL || 'http://127.0.0.1:5000/api';
