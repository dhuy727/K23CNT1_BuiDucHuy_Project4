

checkAdmin();